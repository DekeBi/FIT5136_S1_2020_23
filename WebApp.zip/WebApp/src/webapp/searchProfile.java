package webapp;

import datalayer.DB_user;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "modifyProfile")
public class searchProfile extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String userId = request.getParameter("userId");

       System.out.println(userId);
        DB_user db_user = new DB_user();
        String result = db_user.searchUser(Integer.parseInt(userId));
        System.out.println(result);

        String[] items = result.split(",");


        request.setAttribute("userId",userId);
        request.setAttribute("name",items[0]);
        request.setAttribute("email",items[1]);
        request.setAttribute("password1",items[2]);
        request.setAttribute("dob",items[3]);
        request.setAttribute("nationality",items[4]);
        request.setAttribute("id",items[5]);
        request.setAttribute("gender",items[6]);
        request.setAttribute("allergy",items[7]);
        request.setAttribute("food",items[8]);
        request.setAttribute("qualification",items[9]);
        request.setAttribute("exp",items[10]);
        request.setAttribute("occupation",items[11]);
        request.setAttribute("skill",items[12]);
        request.setAttribute("language",items[13]);
        request.getRequestDispatcher("/updateProfile.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
