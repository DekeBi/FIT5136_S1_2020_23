package webapp;

import appLayer.Mission;
import datalayer.DB_searchMission;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "editMissionCo")
public class editMisson_co extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Mission misson = new Mission();
        misson.setMission_id(Integer.parseInt(request.getParameter("MissionId")));
        misson.setMission_name(request.getParameter("MissionName"));
        misson.setMssion_desc(request.getParameter("Mission Description"));
        misson.setCountry_origin(request.getParameter("Country"));
        misson.setCountry_allowed(request.getParameter("Country Allowed"));
        misson.setJob(request.getParameter("job"));
        misson.setEmp_require(request.getParameter("Employment"));
        misson.setCargo_require(request.getParameter("Cargo"));
        misson.setLaunch_date(request.getParameter("launch"));
        misson.setLocation(request.getParameter("Location"));
        misson.setDuration(request.getParameter("Duration"));
        misson.setStatus(request.getParameter("Status"));
        DB_searchMission db_searchMission = new DB_searchMission();
        db_searchMission.updateMissionCo(misson);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
