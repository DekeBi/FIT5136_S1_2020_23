package webapp;

import datalayer.DB_manage_mission;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "confirmation1")
public class confirmation1 extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String mis_name = request.getParameter("MissionName");
        String mis_desc = request.getParameter("Mission Description");
        String mis_org = request.getParameter("Country");
        String mis_con_allow = request.getParameter("Country Allowed");
        String mis_job = request.getParameter("system_role_id");
        String mis_emp_req = request.getParameter("Employment");
        String mis_cargo = request.getParameter("Cargo");
        String mis_launch = request.getParameter("launch");
        String mis_location = request.getParameter("Location");
        String mis_dur = request.getParameter("Duration");
        String mis_status = request.getParameter("Status");


        request.setAttribute("misname",mis_name);



        try {
            DB_manage_mission db_create_mission = new DB_manage_mission();
            db_create_mission.createMission(mis_name,mis_desc,mis_org,mis_con_allow,mis_job,mis_emp_req,mis_cargo,mis_launch,mis_location,mis_dur
            ,mis_status);




            request.getRequestDispatcher("/congratulations1.jsp").forward(request,response);





        }catch (Exception e)
        {
            e.printStackTrace();

        }





    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
