package webapp;

import datalayer.DB_manage_user;
import datalayer.DB_user;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(name = "updateProfile")
public class updateProfile extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int userid = Integer.parseInt(request.getParameter("userId"));
        String email = request.getParameter("Email");
        String password = request.getParameter("Password");
        String dob = request.getParameter("Date of Birth");
        String nationality = request.getParameter("Nationality");
        String id = request.getParameter("Identification");
        String gender = request.getParameter("Gender");
        String allergy = request.getParameter("Allergies");
        String food = request.getParameter("Food Preference");
        String qualification = request.getParameter("Qualification(s)");
        String exp = request.getParameter("Work Experiences");
        String occupation = request.getParameter("Occupation(s)");
        String skill = request.getParameter("Computer Skills");
        String language = request.getParameter("Language(s)");
        String name = request.getParameter("Name");

        try{
            DB_manage_user db_manage_user = new DB_manage_user();
            db_manage_user.updateUser(userid,email,password,dob,nationality,id,gender,allergy,food,qualification,exp,occupation,
                    skill,language,name);
        }catch (Exception e)
        {
            e.printStackTrace();
        }

        request.getRequestDispatcher("/congratulations2.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
