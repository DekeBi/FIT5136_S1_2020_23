package webapp;

import datalayer.DB_searchCandidate;
import datalayer.DB_shuttle;
import datalayer.DB_user;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "searchCandidate")
public class searchCandidate extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List users = new ArrayList<>();
        try {
            DB_searchCandidate db_user = new DB_searchCandidate();
            users = db_user.searchCandidate();

        }catch (Exception e) {
            e.printStackTrace();
        }
        request.setAttribute("users",users);
        String MissionId = request.getParameter("MissionId");

        String shuttleid = request.getParameter("shuttleid");
        request.setAttribute("shuttleid",shuttleid);
        request.setAttribute("MissionId",MissionId);
        request.getRequestDispatcher("/addCandidates.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
