package webapp;

import datalayer.DB_shuttle;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "searchShuttle")
public class searchShuttle extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List shuttles = new ArrayList<>();
        try {
            DB_shuttle db_shuttle = new DB_shuttle();
            shuttles = db_shuttle.searchShuttle();

        }catch (Exception e) {
            e.printStackTrace();
        }
        request.setAttribute("shuttles",shuttles);

        String MissionId = request.getParameter("MissionId");


        request.setAttribute("MissionId",MissionId);
        request.getRequestDispatcher("/addShuttle.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


    }
}
