package webapp;

import appLayer.Mission;
import datalayer.DB_searchMission;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "searchMissionCo")
public class searchMission_co extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Mission mission = new Mission();
        try {
            DB_searchMission db_searchMission = new DB_searchMission();
            mission = db_searchMission.searchMissionById(request.getParameter("MissionId"));

        }catch (Exception e) {
            e.printStackTrace();
        }
        request.setAttribute("MissionId",mission.getMission_id());
        request.setAttribute("misName",mission.getMission_name());
        request.setAttribute("misDesc",mission.getMssion_desc());
        request.setAttribute("misOrig",mission.getCountry_origin());
        request.setAttribute("misAllow",mission.getCountry_allowed());
        request.setAttribute("misJob",mission.getJob());
        request.setAttribute("misEmp",mission.getEmp_require());
        request.setAttribute("misCargo",mission.getCargo_require());
        request.setAttribute("misLaunch",mission.getLaunch_date());
        request.setAttribute("misLoc",mission.getLocation());
        request.setAttribute("misDur",mission.getDuration());
        request.setAttribute("misStatus",mission.getStatus());

        request.getRequestDispatcher("/modifyMission.jsp").forward(request,response);

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List missions = new ArrayList<>();
        try {
            DB_searchMission db_searchMission = new DB_searchMission();
            missions = db_searchMission.searchMission();

        }catch (Exception e) {
            e.printStackTrace();
        }
        request.setAttribute("missions",missions);
        request.getRequestDispatcher("/missionList-co.jsp").forward(request,response);
    }
}
