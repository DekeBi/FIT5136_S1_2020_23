package datalayer;

import appLayer.Mission;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DB_searchMission {
    //JDBC driver name and database URL
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL= "jdbc:mysql://localhost/webapp";

    //Database credentials
    static final String USER = "webappuser";
    static final String PASS = "tian123456.";
    List missions;

    public Mission searchMissionById(String missionId){
        Mission mission = new Mission();

        Connection conn = null;
        Statement stmt = null;
        String sql = "";
        String result = "";

        try{
            //Step 2 : Register JDBC Driver
            Class.forName(JDBC_DRIVER);

            //Step 3 : Open connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);

            //Step4 : Execute a query
            System.out.println("Creating statement...");
            stmt = conn.createStatement();

            sql = "SELECT * FROM mission WHERE mission_id =" + missionId;

            System.out.println(sql);

            ResultSet rs = stmt.executeQuery(sql);

            //Step 5 : Extract data from result set

            while (rs.next()) {
                mission.setMission_id(rs.getInt(1));
                mission.setMssion_desc(rs.getString(2));
                mission.setCountry_origin(rs.getString(3));
                mission.setCountry_allowed(rs.getString(4));
                mission.setJob(rs.getString(5));
                mission.setEmp_require(rs.getString(6));
                mission.setCargo_require(rs.getString(7));
                mission.setLaunch_date(rs.getString(8));
                mission.setLocation(rs.getString(9));
                mission.setDuration(rs.getString(10));
                mission.setStatus(rs.getString(11));
                mission.setMission_name(rs.getString(12));
                mission.setShuttle_id(rs.getString(13));
                mission.setEmp_1(rs.getString(14));
                mission.setEmp_2(rs.getString(15));
                mission.setEmp_3(rs.getString(16));
                mission.setEmp_4(rs.getString(17));
                mission.setEmp_5(rs.getString(18));
            }

            //Step 6 : Close
            rs.close();
            stmt.close();
            conn.close();

        }catch (SQLException se){
            //errors for JDBC
            se.printStackTrace();
        }catch (Exception e){
            //errors for Class.forName
            e.printStackTrace();
        }finally {
            // close resources
            try{
                if(stmt != null)
                    stmt.close();
            }catch (SQLException se2){
            }

            try{
                if(conn != null)
                    conn.close();
            }catch (SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("Closing DB connection ---Bye");

        System.out.println(result);
        return mission;
    }

    public List searchMission(){

        Connection conn = null;
        Statement stmt = null;
        String sql = "";
        String result = "";

        try{
            //Step 2 : Register JDBC Driver
            Class.forName(JDBC_DRIVER);

            //Step 3 : Open connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);

            //Step4 : Execute a query
            System.out.println("Creating statement...");
            stmt = conn.createStatement();

            sql = "SELECT * FROM mission";

            System.out.println(sql);

            ResultSet rs = stmt.executeQuery(sql);

            //Step 5 : Extract data from result set

            missions = new ArrayList();
            while (rs.next()) {
                Mission mission = new Mission();
                mission.setMission_id(rs.getInt(1));
                mission.setMssion_desc(rs.getString(2));
                mission.setCountry_origin(rs.getString(3));
                mission.setCountry_allowed(rs.getString(4));
                mission.setJob(rs.getString(5));
                mission.setEmp_require(rs.getString(6));
                mission.setCargo_require(rs.getString(7));
                mission.setLaunch_date(rs.getString(8));
                mission.setLocation(rs.getString(9));
                mission.setDuration(rs.getString(10));
                mission.setStatus(rs.getString(11));
                mission.setMission_name(rs.getString(12));
                mission.setShuttle_id(rs.getString(13));
                mission.setEmp_1(rs.getString(14));
                mission.setEmp_2(rs.getString(15));
                mission.setEmp_3(rs.getString(16));
                mission.setEmp_4(rs.getString(17));
                mission.setEmp_5(rs.getString(18));
                missions.add(mission);
            }

            //Step 6 : Close
            rs.close();
            stmt.close();
            conn.close();

        }catch (SQLException se){
            //errors for JDBC
            se.printStackTrace();
        }catch (Exception e){
            //errors for Class.forName
            e.printStackTrace();
        }finally {
            // close resources
            try{
                if(stmt != null)
                    stmt.close();
            }catch (SQLException se2){
            }

            try{
                if(conn != null)
                    conn.close();
            }catch (SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("Closing DB connection ---Bye");

        System.out.println(result);
        return missions;
    }
}
