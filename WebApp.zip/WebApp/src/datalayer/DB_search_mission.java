package datalayer;

import java.sql.*;

public class DB_search_mission {

    //JDBC driver name and database URL
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL= "jdbc:mysql://localhost/webapp";

    //Database credentials
    static final String USER = "webappuser";
    static final String PASS = "tian123456.";


    public String searchMission(int missionId){

        Connection conn = null;
        Statement stmt = null;
        String sql = "";
        String result = "";

        try{
            //Step 2 : Register JDBC Driver
            Class.forName(JDBC_DRIVER);

            //Step 3 : Open connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);

            //Step4 : Execute a query
            System.out.println("Creating statement...");
            stmt = conn.createStatement();

            sql = "SELECT * FROM mission WHERE mission_id = \""+
                    missionId + "\"";

            System.out.println(sql);

            ResultSet rs = stmt.executeQuery(sql);

            //Step 5 : Extract data from result set

            String name = "";
            String desc = "";
            String orig = "";
            String allow = "";
            String job = "";
            String emp = "";
            String cargo = "";
            String launch = "";
            String loc = "";
            String dur = "";
            String status = "";

            if (rs.next()){
                name = rs.getString("mission_name");
                desc = rs.getString("mssion_desc");
                orig = rs.getString("country_origin");
                allow = rs.getString("country_allowed");
                job = rs.getString("job");
                emp = rs.getString("emp_require");
                cargo = rs.getString("cargo_require");
                launch = rs.getString("launch_date");
                loc = rs.getString("Location");
                dur = rs.getString("Duration");
                status = rs.getString("status");

            }

            result = name + "," +desc + "," +orig + "," +allow + "," +job + "," +emp
                    + "," +cargo + "," +launch + "," +loc + "," +dur + "," +status;

            //Step 6 : Close
            rs.close();
            stmt.close();
            conn.close();

        }catch (SQLException se){
            //errors for JDBC
            se.printStackTrace();
        }catch (Exception e){
            //errors for Class.forName
            e.printStackTrace();
        }finally {
            // close resources
            try{
                if(stmt != null)
                    stmt.close();
            }catch (SQLException se2){
            }

            try{
                if(conn != null)
                    conn.close();
            }catch (SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("Closing DB connection ---Bye");

        System.out.println(result);
        return result;
    }
}
