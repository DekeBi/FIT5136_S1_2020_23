package datalayer;

import appLayer.Shuttle;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DB_shuttle {
    //JDBC driver name and database URL
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL= "jdbc:mysql://localhost/webapp";

    //Database credentials
    static final String USER = "webappuser";
    static final String PASS = "tian123456.";
    List shuttles;

    public List searchShuttle(){

        Connection conn = null;
        Statement stmt = null;
        String sql = "";
        String result = "";

        try{
            //Step 2 : Register JDBC Driver
            Class.forName(JDBC_DRIVER);

            //Step 3 : Open connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);

            //Step4 : Execute a query
            System.out.println("Creating statement...");
            stmt = conn.createStatement();

            sql = "SELECT * FROM shuttle";

            System.out.println(sql);

            ResultSet rs = stmt.executeQuery(sql);

            //Step 5 : Extract data from result set

            shuttles = new ArrayList();
            while (rs.next()) {
                Shuttle shuttle = new Shuttle();
                shuttle.setId(rs.getInt(1));
                shuttle.setShuttle_name(rs.getString(2));
                shuttle.setShuttle_manu_year(rs.getString(3));
                shuttle.setFuel_capacity(rs.getString(4));
                shuttle.setPayload_capacity(rs.getString(5));
                shuttle.setTravel_speed(rs.getString(6));
                shuttles.add(shuttle);
            }


            //Step 6 : Close
            rs.close();
            stmt.close();
            conn.close();

        }catch (SQLException se){
            //errors for JDBC
            se.printStackTrace();
        }catch (Exception e){
            //errors for Class.forName
            e.printStackTrace();
        }finally {
            // close resources
            try{
                if(stmt != null)
                    stmt.close();
            }catch (SQLException se2){
            }

            try{
                if(conn != null)
                    conn.close();
            }catch (SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("Closing DB connection ---Bye");

        System.out.println(result);
        return shuttles;
    }
}
