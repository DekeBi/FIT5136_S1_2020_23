package datalayer;

import appLayer.Shuttle;
import appLayer.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DB_searchCandidate {
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL= "jdbc:mysql://localhost/webapp";

    //Database credentials
    static final String USER = "webappuser";
    static final String PASS = "tian123456.";
    List users;
    public List searchCandidate(){

        Connection conn = null;
        Statement stmt = null;
        String sql = "";
        String result = "";

        try{
            //Step 2 : Register JDBC Driver
            Class.forName(JDBC_DRIVER);

            //Step 3 : Open connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);

            //Step4 : Execute a query
            System.out.println("Creating statement...");
            stmt = conn.createStatement();

            sql = "SELECT * FROM user WHERE user_type = 'ca'";

            System.out.println(sql);

            ResultSet rs = stmt.executeQuery(sql);

            //Step 5 : Extract data from result set

            users = new ArrayList();
            while (rs.next()) {
                User user = new User();
                user.setId(rs.getInt(1));
                user.setUser_email(rs.getString(2));
                user.setUser_password(rs.getString(3));
                user.setUser_dob(rs.getString(4));
                user.setUser_nationality(rs.getString(5));
                user.setUser_identification(rs.getString(6));
                user.setUser_gender(rs.getString(7));
                user.setUser_allergy(rs.getString(8));
                user.setUser_food(rs.getString(9));
                user.setUser_qualification(rs.getString(10));
                user.setUser_work_exp(rs.getString(11));
                user.setUser_occupation(rs.getString(12));
                user.setUser_skill(rs.getString(13));
                user.setUser_language(rs.getString(14));
                user.setUser_name(rs.getString(15));
                user.setUser_type(rs.getString(16));
                users.add(user);
            }


            //Step 6 : Close
            rs.close();
            stmt.close();
            conn.close();

        }catch (SQLException se){
            //errors for JDBC
            se.printStackTrace();
        }catch (Exception e){
            //errors for Class.forName
            e.printStackTrace();
        }finally {
            // close resources
            try{
                if(stmt != null)
                    stmt.close();
            }catch (SQLException se2){
            }

            try{
                if(conn != null)
                    conn.close();
            }catch (SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("Closing DB connection ---Bye");

        System.out.println(result);
        return users;
    }
}
