package datalayer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DB_manage_mission {

    //JDBC driver name and database URL
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL= "jdbc:mysql://localhost/webapp";

    //Database credentials
    static final String USER = "webappuser";
    static final String PASS = "bideke123456";

    public void createMission(String mission_name,String mission_desc,String country_orig,String country_allow,String job,String emp_req
            ,String cargo,String launch_date,String location,String duration,String status){

        Connection conn = null;
        Statement stmt = null;
        String sql = "";

        try{
            //Step 2 : Register JDBC Driver
            Class.forName(JDBC_DRIVER);

            //Step 3 : Open connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);

            //Step4 : Execute a query
            System.out.println("Creating statement...");
            stmt = conn.createStatement();

            sql = "INSERT INTO mission(`mission_name`, `mssion_desc`, `country_origin`, `country_allowed`, " +
                    "`job`, `emp_require`, `cargo_require`, `launch_date`, `Location`, `Duration`, " +
                    "`status`) " +
                    "VALUES ('"+mission_name+"', '"+mission_desc+"', '"+country_orig+"', '"+country_allow+"', '"+job+"', '"+emp_req+"', '"+cargo+"', " +
                    "'"+launch_date+"', '"+location+"', '"+duration+"', '"+status+"');";

            System.out.println(sql);

            stmt.executeUpdate(sql);

            stmt.close();
            conn.close();

        }catch (SQLException se){
            //errors for JDBC
            se.printStackTrace();
        }catch (Exception e){
            //errors for Class.forName
            e.printStackTrace();
            System.out.println("HAHAHAHA");
        }finally {
            // close resources
            try{
                if(stmt != null)
                    stmt.close();
            }catch (SQLException se2){
            }

            try{
                if(conn != null)
                    conn.close();
            }catch (SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("Closing DB connection ---Bye");


    }

    public void upDateMission(int mis_id,String mission_name,String mission_desc,String country_orig,String country_allow,String job,String emp_req
            ,String cargo,String launch_date,String location,String duration,String status,int shuttle_id,int empid1,int empid2,int empid3,int empid4,
                              int empid5){
        Connection conn = null;
        Statement stmt = null;
        String sql = "";

        try{
            //Step 2 : Register JDBC Driver
            Class.forName(JDBC_DRIVER);

            //Step 3 : Open connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL,USER,PASS);

            //Step4 : Execute a query
            System.out.println("Creating statement...");
            stmt = conn.createStatement();

            sql = "UPDATE mission SET mission_name = '"+mission_name+"', mssion_desc = '"+mission_desc+"'," +
                    "country_origin = '"+country_orig+"', country_allowed = '"+country_allow+"',job = '"+job+"' ,emp_require = '"+emp_req+"'" +
                    ",cargo_require = '"+cargo+"',launch_date = '"+launch_date+"',Location = '"+location+"',Duration = '"+duration+"'" +
                    ",status = '"+status+"' ,shuttle_id = \""+shuttle_id+"\",emp_1 = \""+empid1+"\" ,emp_2 = \""+empid2+"\" ,emp_3 = \""+empid3+"\" " +
                    ",emp_4 = \""+empid4+"\",emp_5 = \""+empid5+"\" " +
                    "WHERE mission_id = \""+
                    mis_id + "\"";



            System.out.println(sql);

            stmt.executeUpdate(sql);

            stmt.close();
            conn.close();

        }catch (SQLException se){
            //errors for JDBC
            se.printStackTrace();
        }catch (Exception e){
            //errors for Class.forName
            e.printStackTrace();
            System.out.println("HAHAHAHA");
        }finally {
            // close resources
            try{
                if(stmt != null)
                    stmt.close();
            }catch (SQLException se2){
            }

            try{
                if(conn != null)
                    conn.close();
            }catch (SQLException se){
                se.printStackTrace();
            }
        }
        System.out.println("Closing DB connection ---Bye");


    }
}
