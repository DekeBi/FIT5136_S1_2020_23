package appLayer;

public class Shuttle {
    private int id;
    private String shuttle_name;
    private String shuttle_manu_year;
    private String fuel_capacity;
    private String payload_capacity;
    private String travel_speed;

    public Shuttle(){}

    public Shuttle(int id, String shuttle_name, String shuttle_manu_year, String fuel_capacity, String payload_capacity, String travel_speed) {
        this.id = id;
        this.shuttle_name = shuttle_name;
        this.shuttle_manu_year = shuttle_manu_year;
        this.fuel_capacity = fuel_capacity;
        this.payload_capacity = payload_capacity;
        this.travel_speed = travel_speed;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getShuttle_name() {
        return shuttle_name;
    }

    public void setShuttle_name(String shuttle_name) {
        this.shuttle_name = shuttle_name;
    }

    public String getShuttle_manu_year() {
        return shuttle_manu_year;
    }

    public void setShuttle_manu_year(String shuttle_manu_year) {
        this.shuttle_manu_year = shuttle_manu_year;
    }

    public String getFuel_capacity() {
        return fuel_capacity;
    }

    public void setFuel_capacity(String fuel_capacity) {
        this.fuel_capacity = fuel_capacity;
    }

    public String getPayload_capacity() {
        return payload_capacity;
    }

    public void setPayload_capacity(String payload_capacity) {
        this.payload_capacity = payload_capacity;
    }

    public String getTravel_speed() {
        return travel_speed;
    }

    public void setTravel_speed(String travel_speed) {
        this.travel_speed = travel_speed;
    }
}
