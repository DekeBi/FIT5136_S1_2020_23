package appLayer;

public class Mission {
    private int mission_id;
    private String mssion_desc;
    private String country_origin;
    private String country_allowed;
    private String job;
    private String emp_require;
    private String cargo_require;
    private String launch_date;
    private String Location;
    private String Duration;
    private String status;
    private String mission_name;
    private String shuttle_id;
    private String emp_1;
    private String emp_2;
    private String emp_3;
    private String emp_4;
    private String emp_5;

    public Mission(){

    }

    public Mission(int mission_id, String mssion_desc, String country_origin, String country_allowed, String job, String emp_require, String cargo_require, String launch_date, String location, String duration, String status, String mission_name, String shuttle_id, String emp_1, String emp_2, String emp_3, String emp_4, String emp_5) {
        this.mission_id = mission_id;
        this.mssion_desc = mssion_desc;
        this.country_origin = country_origin;
        this.country_allowed = country_allowed;
        this.job = job;
        this.emp_require = emp_require;
        this.cargo_require = cargo_require;
        this.launch_date = launch_date;
        Location = location;
        Duration = duration;
        this.status = status;
        this.mission_name = mission_name;
        this.shuttle_id = shuttle_id;
        this.emp_1 = emp_1;
        this.emp_2 = emp_2;
        this.emp_3 = emp_3;
        this.emp_4 = emp_4;
        this.emp_5 = emp_5;
    }

    public int getMission_id() {
        return mission_id;
    }

    public void setMission_id(int mission_id) {
        this.mission_id = mission_id;
    }

    public String getMssion_desc() {
        return mssion_desc;
    }

    public void setMssion_desc(String mssion_desc) {
        this.mssion_desc = mssion_desc;
    }

    public String getCountry_origin() {
        return country_origin;
    }

    public void setCountry_origin(String country_origin) {
        this.country_origin = country_origin;
    }

    public String getCountry_allowed() {
        return country_allowed;
    }

    public void setCountry_allowed(String country_allowed) {
        this.country_allowed = country_allowed;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public String getEmp_require() {
        return emp_require;
    }

    public void setEmp_require(String emp_require) {
        this.emp_require = emp_require;
    }

    public String getCargo_require() {
        return cargo_require;
    }

    public void setCargo_require(String cargo_require) {
        this.cargo_require = cargo_require;
    }

    public String getLaunch_date() {
        return launch_date;
    }

    public void setLaunch_date(String launch_date) {
        this.launch_date = launch_date;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String location) {
        Location = location;
    }

    public String getDuration() {
        return Duration;
    }

    public void setDuration(String duration) {
        Duration = duration;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMission_name() {
        return mission_name;
    }

    public void setMission_name(String mission_name) {
        this.mission_name = mission_name;
    }

    public String getShuttle_id() {
        return shuttle_id;
    }

    public void setShuttle_id(String shuttle_id) {
        this.shuttle_id = shuttle_id;
    }

    public String getEmp_1() {
        return emp_1;
    }

    public void setEmp_1(String emp_1) {
        this.emp_1 = emp_1;
    }

    public String getEmp_2() {
        return emp_2;
    }

    public void setEmp_2(String emp_2) {
        this.emp_2 = emp_2;
    }

    public String getEmp_3() {
        return emp_3;
    }

    public void setEmp_3(String emp_3) {
        this.emp_3 = emp_3;
    }

    public String getEmp_4() {
        return emp_4;
    }

    public void setEmp_4(String emp_4) {
        this.emp_4 = emp_4;
    }

    public String getEmp_5() {
        return emp_5;
    }

    public void setEmp_5(String emp_5) {
        this.emp_5 = emp_5;
    }
}
