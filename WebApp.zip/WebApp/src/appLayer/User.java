package appLayer;

import datalayer.DB_user;

public class User {

    private int id;
    private String user_email;
    private String user_password;
    private String user_dob;
    private String user_nationality;
    private String user_identification;
    private String user_gender;
    private String user_allergy;
    private String user_food;
    private String user_qualification;
    private String user_work_exp;
    private String user_occupation;
    private String user_skill;
    private String user_language;
    private String user_name;
    private String user_type;

    public User(){}

    public User(int id, String user_email, String user_password, String user_dob, String user_nationality, String user_identification, String user_gender, String user_allergy, String user_food, String user_qualification, String user_work_exp, String user_occupation, String user_skill, String user_language, String user_name, String user_type) {
        this.id = id;
        this.user_email = user_email;
        this.user_password = user_password;
        this.user_dob = user_dob;
        this.user_nationality = user_nationality;
        this.user_identification = user_identification;
        this.user_gender = user_gender;
        this.user_allergy = user_allergy;
        this.user_food = user_food;
        this.user_qualification = user_qualification;
        this.user_work_exp = user_work_exp;
        this.user_occupation = user_occupation;
        this.user_skill = user_skill;
        this.user_language = user_language;
        this.user_name = user_name;
        this.user_type = user_type;
    }

    public String getUser_email() {
        return user_email;
    }

    public void setUser_email(String user_email) {
        this.user_email = user_email;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUser_password() {
        return user_password;
    }

    public void setUser_password(String user_password) {
        this.user_password = user_password;
    }

    public String getUser_dob() {
        return user_dob;
    }

    public void setUser_dob(String user_dob) {
        this.user_dob = user_dob;
    }

    public String getUser_nationality() {
        return user_nationality;
    }

    public void setUser_nationality(String user_nationality) {
        this.user_nationality = user_nationality;
    }

    public String getUser_identification() {
        return user_identification;
    }

    public void setUser_identification(String user_identification) {
        this.user_identification = user_identification;
    }

    public String getUser_gender() {
        return user_gender;
    }

    public void setUser_gender(String user_gender) {
        this.user_gender = user_gender;
    }

    public String getUser_allergy() {
        return user_allergy;
    }

    public void setUser_allergy(String user_allergy) {
        this.user_allergy = user_allergy;
    }

    public String getUser_food() {
        return user_food;
    }

    public void setUser_food(String user_food) {
        this.user_food = user_food;
    }

    public String getUser_qualification() {
        return user_qualification;
    }

    public void setUser_qualification(String user_qualification) {
        this.user_qualification = user_qualification;
    }

    public String getUser_work_exp() {
        return user_work_exp;
    }

    public void setUser_work_exp(String user_work_exp) {
        this.user_work_exp = user_work_exp;
    }

    public String getUser_occupation() {
        return user_occupation;
    }

    public void setUser_occupation(String user_occupation) {
        this.user_occupation = user_occupation;
    }

    public String getUser_skill() {
        return user_skill;
    }

    public void setUser_skill(String user_skill) {
        this.user_skill = user_skill;
    }

    public String getUser_language() {
        return user_language;
    }

    public void setUser_language(String user_language) {
        this.user_language = user_language;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getUser_type() {
        return user_type;
    }

    public void setUser_type(String user_type) {
        this.user_type = user_type;
    }

    public boolean isValidUserCredentials(String username, String userPassword )
    {

        DB_user db_user = new DB_user();


        return db_user.isValidUserLogin(username,userPassword);
    }

}
